## weavegate: PASS
scenario: double-booking | schedules explored: 18 (exhausted) | violating: none
flaky: false (repeat=20)
