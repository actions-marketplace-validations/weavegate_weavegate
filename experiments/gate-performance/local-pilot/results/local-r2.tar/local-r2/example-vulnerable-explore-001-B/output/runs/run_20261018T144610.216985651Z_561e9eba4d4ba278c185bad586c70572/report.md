## weavegate: FAIL (WG001)
scenario: double-booking | schedules explored: 1 | violating: sch_6f1ffd61cc07
assertion: one-active-reservation-per-seat
flaky: false (repeat=20)
replay: weavegate run --config .weavegate/config.yaml --scenario double-booking --variant main --replay sch_6f1ffd61cc07 --repeat 20

error[WG001]: invariant violated under a controlled schedule
  observed:  one-active-reservation-per-seat returned 1 row: active_reservations=2 seat_id=7
  assertion: one-active-reservation-per-seat
  invariant: a declared state invariant must hold under every release schedule the database permits
  reason:    commonly a read-then-write path without a lock or a unique constraint
  help:      add a unique constraint on the contested key
             take a pessimistic lock (SELECT ... FOR UPDATE) before insert
             use an idempotency key on the write
  evidence:  schedule sch_6f1ffd61cc07 · trace.json · observation.json · 1 violating row
