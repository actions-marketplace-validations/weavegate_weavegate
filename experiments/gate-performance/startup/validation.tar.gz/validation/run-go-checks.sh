#!/usr/bin/env bash
set -eu
export GOCACHE=/tmp/weavegate-a3/go-cache
root=/tmp/weavegate-a3
mkdir -p "$root/acceptance/go"
gofmt -l cmd internal fixtures experiments > "$root/gofmt.log"
test ! -s "$root/gofmt.log"
go vet ./... > "$root/vet.log" 2>&1
go build ./... > "$root/build.log" 2>&1
go test ./cmd/... -short -count=1 > "$root/cmd-short.log" 2>&1
go test ./internal/... ./fixtures/... ./experiments/... ./cmd/... -count=1 -timeout 30m > "$root/go-all.log" 2>&1
go test ./internal/sut/external -v -count=20 > "$root/acceptance/go/go.log" 2>&1
go test ./internal/sut/external -race -count=20 > "$root/acceptance/go/race.log" 2>&1
python3 scripts/test-external-sut-go-results.py > "$root/acceptance/go/recorder-test.log" 2>&1
python3 scripts/record-external-sut-go-results.py --log "$root/acceptance/go/go.log" --output "$root/acceptance/go/go.json" --revision "$(git rev-parse d929c11)" --command 'go test ./internal/sut/external -v -count=20' --go-version "$(go version)"
python3 scripts/check-external-sut-acceptance.py --results "$root/acceptance/go/go.json" --require-complete
