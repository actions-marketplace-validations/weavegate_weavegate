#!/usr/bin/env bash
set -eu
root=/tmp/weavegate-a3
for variant in fixed vulnerable; do
  sdk/java/mvnw -B -f "$root/adoption/$variant/pom.xml" package > "$root/adoption/$variant/package.log" 2>&1
  set +e
  "$root/candidate" run --config "$root/adoption/$variant/.weavegate/config.yaml" --scenario double-booking --replay "$root/adoption/$variant/.weavegate/schedules/sch_6f1ffd61cc07.json" --repeat 20 --out "$root/adoption/$variant/result" > "$root/adoption/$variant/run.stdout" 2> "$root/adoption/$variant/run.stderr"
  result=$?
  set -e
  if [ "$variant" = fixed ]; then test "$result" = 0; else test "$result" = 2; fi
  echo "$variant exit=$result"
done
