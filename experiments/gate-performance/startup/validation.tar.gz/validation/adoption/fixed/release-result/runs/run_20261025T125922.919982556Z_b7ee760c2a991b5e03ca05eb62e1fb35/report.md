## weavegate: PASS
scenario: double-booking | schedules explored: 0 | replayed: sch_6f1ffd61cc07
flaky: false (repeat=20)
replay: weavegate run --config /tmp/weavegate-a3/adoption/fixed/.weavegate/config.yaml --scenario double-booking --variant main --replay sch_6f1ffd61cc07 --repeat 20
