#!/usr/bin/env bash
set -eu
root=/tmp/weavegate-a3
mkdir -p "$root/acceptance/java"
sdk/java/mvnw -B -f sdk/java/pom.xml verify -DargLine=-XX:TieredStopAtLevel=1 -Dweavegate.repetitions=20 -Dweavegate.evidence=/tmp/weavegate-a3/acceptance/java/java.log > "$root/acceptance/java/build.log" 2>&1
python3 scripts/test-external-sut-java-results.py > "$root/acceptance/java/recorder-test.log" 2>&1
python3 scripts/record-external-sut-java-results.py --log "$root/acceptance/java/java.log" --build-log "$root/acceptance/java/build.log" --output "$root/acceptance/java/java.json" --revision "$(git rev-parse d929c11)" --command 'sdk/java/mvnw -B -f sdk/java/pom.xml verify -DargLine=-XX:TieredStopAtLevel=1 -Dweavegate.repetitions=20 -Dweavegate.evidence=/tmp/weavegate-a3/acceptance/java/java.log'
python3 scripts/check-external-sut-acceptance.py --results "$root/acceptance/java/java.json" --require-complete
