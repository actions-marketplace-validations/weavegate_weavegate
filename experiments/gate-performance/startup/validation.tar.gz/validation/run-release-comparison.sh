#!/usr/bin/env bash
set -eu
root=/tmp/weavegate-a3
baseline="$root/release-baseline/weavegate_0.2.0_linux_amd64/weavegate"
for variant in fixed vulnerable; do
  set +e
  "$baseline" run --config "$root/adoption/$variant/.weavegate/config.yaml" --scenario double-booking --replay "$root/adoption/$variant/.weavegate/schedules/sch_6f1ffd61cc07.json" --repeat 20 --out "$root/adoption/$variant/release-result" > "$root/adoption/$variant/release.stdout" 2> "$root/adoption/$variant/release.stderr"
  result=$?
  set -e
  if [ "$variant" = fixed ]; then test "$result" = 0; else test "$result" = 2; fi
  echo "$variant v0.2.0 exit=$result"
done
python3 - <<'PY'
from pathlib import Path
import json
root=Path('/tmp/weavegate-a3/adoption')
for variant in ['fixed','vulnerable']:
    parent=next((root/variant/'release-result/runs').iterdir())
    candidate=next((root/variant/'result/runs').iterdir())
    for name in ['scenario.json','observation.json','trace.json','report.md','schedule.json']:
        assert (parent/name).read_bytes()==(candidate/name).read_bytes(), (variant,name)
    for path in [parent,candidate]:
        observation=json.loads((path/'observation.json').read_text())
        manifest=json.loads((path/'manifest.json').read_text())
        assert observation['repeat']==20 and not observation['flaky']
        assert len(observation['fingerprints'])==1
        assert not manifest['cleanup_failed']
    print(variant, 'five deterministic files byte-identical to v0.2.0')
PY
