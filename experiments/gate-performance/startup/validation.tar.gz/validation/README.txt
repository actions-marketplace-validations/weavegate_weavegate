A3 validation evidence, separate from performance tuning.
Implementation source: d929c11f23add95755d2708ab35760bdf40880a4
Later branch commits only retain evidence and documentation.

run-go-checks.sh and run-java-checks.sh are the executed local commands.
The completed paired command is recorded by acceptance/paired.json.
acceptance/paired-interrupted.log is an interrupted earlier attempt and is
excluded from the acceptance manifest.

The adoption examples use the sources retained by the local pilot under
experiments/gate-performance/local-pilot/registration-r2, built with SDK 0.2.0.
Their application.properties contains only an empty-default environment
placeholder for BOOKING_DB_PASSWORD; no fixture credentials are retained.
The Java build log contains a transient localhost JDBC endpoint without a
password. Original logs are retained verbatim.

No binary or JAR bytes are included; jar-identity.json records the executable
JAR and nested dependency hashes. The release checksum file authenticates the
downloaded official archive used by run-release-comparison.sh.

These acceptance tests ran concurrently and their durations must not be used
as performance measurements or pooled with E1/tuning samples.
