## weavegate: PASS
scenario: concurrent-assign | schedules explored: 0 | replayed: sch_7dcb74b1e506
flaky: false (repeat=20)
replay: weavegate run --config /home/daeun/weavegate/fixtures/spring-matching/.weavegate/config.yaml --scenario concurrent-assign --variant fixed --replay sch_7dcb74b1e506 --repeat 20
