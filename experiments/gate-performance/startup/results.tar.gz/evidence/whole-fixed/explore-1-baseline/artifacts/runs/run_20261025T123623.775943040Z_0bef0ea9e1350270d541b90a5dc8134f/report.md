## weavegate: PASS
scenario: concurrent-assign | schedules explored: 18 (exhausted) | violating: none
flaky: false (repeat=20)
